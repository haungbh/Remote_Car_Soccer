//
//  ViewController.swift
//  MonitorOfPi
//
//  Created by Y.R.Zeng on 2018/6/1.
//  Copyright © 2018年 Y.R.Zeng. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var score1: UILabel!
    @IBOutlet weak var score2: UILabel!
    var iStream : InputStream? = nil
    var oStream : OutputStream? = nil
    
    var iStream2 : InputStream? = nil //goal 1
    var oStream2 : OutputStream? = nil  //goal 1
    
    var iStream3 : InputStream? = nil //goal 2
    var oStream3 : OutputStream? = nil  //goal 2
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let _ = Stream.getStreamsToHost(withName: "172.20.10.4", port: 8888, inputStream: &iStream, outputStream: &oStream)
        iStream?.open()
        oStream?.open()
        
        let _ = Stream.getStreamsToHost(withName: "172.20.10.8", port: 8888, inputStream: &iStream2, outputStream: &oStream2)
        iStream2?.open()
        oStream2?.open()
        
        let _ = Stream.getStreamsToHost(withName: "172.20.10.11", port: 8888, inputStream: &iStream3, outputStream: &oStream3)
        iStream3?.open()
        oStream3?.open()
        
        DispatchQueue.global().async
        {
            self.receiveData(available: { (string) in
                DispatchQueue.main.async {
                    self.score1.text = string
                    if (string == "0\n")
                    {
                        self.score1.text = "0"
                        self.score2.text = "0"
                    }
                }
            })
        }
        DispatchQueue.global().async
            {
                self.receiveData2(available: { (string) in
                    DispatchQueue.main.async {
                        self.score2.text = string
                        if (string == "0\n")
                        {
                            self.score1.text = "0"
                            self.score2.text = "0"
                        }
                    }
                })
        }
    }
    
    func receiveData(available: (_ string:String?)->Void)
    {
        var buf = Array(repeating: UInt8(0),count:1024)
        while true
        {
            if let n = iStream2?.read(&buf,maxLength:1024)
            {
                let data = Data(bytes: buf, count :n)
                let string = String(data:data,encoding: .utf8)
                print(string)
                print("yo")
                available(string)
                
            }
        }
    }
    
    func receiveData2(available: (_ string:String?)->Void)
    {
        var buf = Array(repeating: UInt8(0),count:1024)
        while true
        {
            if let n = iStream3?.read(&buf,maxLength:1024)
            {
                let data = Data(bytes: buf, count :n)
                let string = String(data:data,encoding: .utf8)
                print(string)
                available(string)
                
            }
        }
    }
    
    func send(_ string:String)
    {
        var buf = Array(repeating: UInt8(0),count:1024)
        let data = string.data(using : .utf8)!
        
        data.copyBytes(to: &buf, count: data.count)
        oStream?.write(buf, maxLength: data.count)
        
    }

    @IBAction func clickUp(_ sender: Any) {
        send("go")
    }
    @IBAction func clickLeft(_ sender: Any) {
        send("left")
    }
    @IBAction func clickRight(_ sender: Any) {
        send("right")
    }
    @IBAction func clickStop(_ sender: Any) {
        send("stop")
    }
    @IBAction func clickBack(_ sender: Any) {
        send("back")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }


}

